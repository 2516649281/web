<template>
  <div>
    <!-- <router-link to="/teacher">teacher</router-link>
    <router-link to="/student">student</router-link> -->
    <!-- <router-link to="/"></router-link> -->
    <router-view />
  </div>
</template>
<script>
export default {};
</script>

<style></style>
