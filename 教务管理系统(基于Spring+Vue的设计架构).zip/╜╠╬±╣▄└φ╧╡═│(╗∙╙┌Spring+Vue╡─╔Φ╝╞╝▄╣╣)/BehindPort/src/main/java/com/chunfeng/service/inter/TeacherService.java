package com.chunfeng.service.inter;

import com.baomidou.mybatisplus.extension.service.IService;
import com.chunfeng.dao.entity.Teacher;

/**
 * 教师业务层接口
 */
public interface TeacherService extends IService<Teacher> {
}
