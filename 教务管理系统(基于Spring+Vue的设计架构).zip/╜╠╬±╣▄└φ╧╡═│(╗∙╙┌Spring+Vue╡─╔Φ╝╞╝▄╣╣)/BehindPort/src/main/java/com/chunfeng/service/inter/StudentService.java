package com.chunfeng.service.inter;

import com.baomidou.mybatisplus.extension.service.IService;
import com.chunfeng.dao.entity.Student;

/**
 * 学生业务层接口
 */
public interface StudentService extends IService<Student> {
}
