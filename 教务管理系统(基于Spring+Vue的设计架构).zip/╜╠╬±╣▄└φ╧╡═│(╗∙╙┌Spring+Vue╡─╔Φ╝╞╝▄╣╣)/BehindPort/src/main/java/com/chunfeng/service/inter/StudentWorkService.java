package com.chunfeng.service.inter;

import com.baomidou.mybatisplus.extension.service.IService;
import com.chunfeng.dao.entity.StudentWork;

/**
 * 学生-作业业务层接口
 */
public interface StudentWorkService extends IService<StudentWork> {
}
