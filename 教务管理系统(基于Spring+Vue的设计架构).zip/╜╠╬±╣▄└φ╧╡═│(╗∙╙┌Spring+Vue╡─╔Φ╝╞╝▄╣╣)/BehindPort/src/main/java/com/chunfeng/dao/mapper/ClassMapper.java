package com.chunfeng.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chunfeng.dao.entity.Class;
import org.springframework.stereotype.Repository;

/**
 * 班级mapper
 */
@Repository
public interface ClassMapper extends BaseMapper<Class> {
}
