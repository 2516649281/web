package com.chunfeng.service.inter;

import com.baomidou.mybatisplus.extension.service.IService;
import com.chunfeng.dao.entity.Class;

/**
 * 班级业务层接口
 */
public interface ClassService extends IService<Class> {
}
